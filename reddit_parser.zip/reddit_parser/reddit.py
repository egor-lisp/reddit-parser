import requests, pickle
from reddit_parser.reddit_api import Reddit_api
from reddit_parser.utils import Utils


class User():
    url = ''
    username = ''
    logo_url = ''
    description = ''
    comment_karma = 0
    link_karma = 0
    total_karma = 0
    created_date = ''
    is_email_verif = False
    posts = []

class Subreddit():
    url = ''
    name = ''
    logo_url = ''
    description = ''
    created_date = ''
    subs_count = 0
    active_subs = 0
    moderators = []
    rules = ''
    karma = None
    newest_post_date = ''
    oldest_post_date = ''
    posts_count = 0

class Post():
    url = ''
    title = ''
    author = {}
    created_date = ''
    flair = []
    text = ''
    picture = None
    upvotes = 0
    upvote_ratio = 0
    comments_count = 0

class Pushshift_api():
    """ Api для постов """
    api = 'https://api.pushshift.io/reddit'

    def get_subbredit_posts(self, subreddit):
        """ Получаем первый и ласт пост и кол-во """
        url = f'{self.api}/search/submission/?subreddit={subreddit}&metadata=true&size=1'
        response = requests.get(url).json()

        # Получаем кол-во постов
        posts_count = response['metadata']['total_results']
        # Получаем первый пост
        first_post = response['data'][0]
        # Получаем последний пост
        url = f'{self.api}/search/submission/?subreddit={subreddit}&size=1&after={int(posts_count-1)}'
        response = requests.get(url).json()
        last_post = response['data'][0]

        return {'posts_count': posts_count, 'first_post': first_post, 'last_post': last_post}


class Reddit_parser():

    def __init__(self):
        self.api = Reddit_api()
        self.push_api = Pushshift_api()
        session = requests.Session()
        session.headers.update({'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36'})
        with open('reddit_parser/cookies/session', 'rb') as f:
            session.cookies.update(pickle.load(f))
            f.close()
        self.session = session
        self.utils = Utils()

    def dict_from_class(self, class_):
        data = class_.__dict__
        return data

    def get_user_info(self, username, max_count=0):
        # Получаем json от реддита
        info_url = self.api.get_user_info_url(username)
        response = self.session.get(info_url)
        json = response.json()

        user = User()

        info = json['data']
        subreddit = json['data']['subreddit']

        user.username = username
        user.url = 'https://www.reddit.com/user/'+username

        user.description = subreddit['description']

        user.logo_url = info['icon_img']
        user.comment_karma = info['comment_karma']
        user.link_karma = info['link_karma']
        user.total_karma = info['total_karma']
        user.created_date = info['created_utc']
        user.is_email_verif = info['has_verified_email']

        if max_count > 0:
            user.posts = self.get_user_posts(username, max_count)

        return self.dict_from_class(user)

    def get_user_posts(self, username, max_count):
        url = f'https://www.reddit.com/user/{username}/posts/'

        response = self.session.get(url)
        raw_data = self.utils.extract_data(response.text)

        posts_models = raw_data['posts']['models']
        posts_list = []
        done = 0
        for key in posts_models.keys():
            post = Post()
            model = posts_models[key]

            post.url = model['permalink']
            post.title = model['title']
            try:
                if 'richtextContent' in model['media'].keys():
                    post.text = self.utils.extract_post_text(
                        model['media']['richtextContent'])
            except:
                pass
            # Собираем инфу об авторе
            username = model['author']
            post.author = self.get_user_info(username)

            # Остальна инфа
            try:
                if 'content' in model['media']:
                    post.picture = model['media']['content']
            except:
                pass
            post.created_date = model['created']
            post.flair = self.utils.extract_flair(model['flair'])
            post.comments_count = model['numComments']
            post.upvotes = model['score']
            post.upvote_ratio = model['upvoteRatio']
            
            posts_list.append(self.dict_from_class(post))
            done += 1
            if done >= max_count:
                break
        return posts_list

    def get_subreddit_info(self, url):
        response = self.session.get(url)
        raw_data = self.utils.extract_data(response.text)

        # Информация о сабреддите
        subreddits = raw_data['subreddits']

        # Получаем ключ
        about = subreddits['about']
        first_key = next(iter(about))

        # Вкладкии с информацией
        about = about[first_key]
        model = subreddits['models'][first_key]
        rules = subreddits['rules'][first_key]

        subreddit = Subreddit()

        subreddit.url = url
        subreddit.name = url.split('r/')[1].replace('/', '')

        # Парсинг вкладки about
        subreddit.description = about['publicDescription']
        subreddit.created_date = about['created']
        subreddit.subs_count = about['subscribers']
        subreddit.active_subs = about['accountsActive']

        # Парсинг вкладки model
        subreddit.logo_url = model['communityIcon']

        # Парсинг вкладки rules
        rules_list = rules['rules']
        rules_string = ''
        for rule in rules_list:
            rules_string += rule['shortName'] + ' '
        subreddit.rules = rules_string

        # Парсинг модеров и кармы по принципу
        models = raw_data['widgets']['models']

        for model in models.keys():
            if 'widget_moderators' in model:
                moders_list = models[model]['mods']
        for moder in moders_list:
            subreddit.moderators.append(moder['name'])
            if subreddit.name.lower() in moder['name'].lower():
                moder_karma = self.get_user_info(moder['name'])['total_karma']
                subreddit.karma = moder_karma

        # Парсинг первоого и последнего поста
        posts = self.push_api.get_subbredit_posts(subreddit.name)
        subreddit.posts_count = posts['posts_count']
        subreddit.newest_post_date = posts['first_post']['created_utc']
        subreddit.oldest_post_date = posts['last_post']['created_utc']

        return self.dict_from_class(subreddit)

    def get_post_info(self, url):
        # Получаем выдачу реддита
        response = self.session.get(url)
        raw_data = self.utils.extract_data(response.text)

        # Берем нужный раздел из выдачи
        posts = raw_data['posts']['models']
        first_key = next(iter(posts))
        data = posts[first_key]

        post = Post()

        post.url = data['permalink']
        post.title = data['title']
        if 'richtextContent' in data['media'].keys():
            post.text = self.utils.extract_post_text(
                data['media']['richtextContent'])
        # Собираем инфу об авторе
        username = data['author']
        post.author = self.get_user_info(username)

        # Остальна инфа
        if 'content' in data['media']:
            post.picture = data['media']['content']
        post.created_date = data['created']
        post.flair = self.utils.extract_flair(data['flair'])
        post.comments_count = data['numComments']
        post.upvotes = data['score']
        post.upvote_ratio = data['upvoteRatio']

        return self.dict_from_class(post)

    def retrieve_url(self, url, max_count=0):
        url_type = self.api.get_url_type(url)
        data = {'request_type': url_type}

        if url_type == 'invalid_url':
            data['content'] = {}

        elif url_type == 'user':
            username = url.split('reddit.com/user/')[1].replace('/', '')
            data['content'] = self.get_user_info(username, max_count)

        elif url_type == 'subreddit':
            data['content'] = self.get_subreddit_info(url)

        elif url_type == 'post':
            data['content'] = self.get_post_info(url)

        return data
