from reddit import Reddit_parser


reddit = Reddit_parser()

info = reddit.retrieve_url('https://www.reddit.com/user/dogecartel-coin/')
print(info)
info1 = reddit.retrieve_url('https://www.reddit.com/r/metanftworld/')
print(info1)

